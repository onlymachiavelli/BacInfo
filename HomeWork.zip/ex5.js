const list = document.getElementById("list");

function addElement(val) {
  const item = document.createElement("li");

  item.textContent = val;

  list.appendChild(item);
}

for (let i = 0; i < 3; i++) {
  var listItem = prompt("Enter Item !");
  addElement(listItem);
}
