const labelA = prompt("Label 1 ");
const labelB = prompt("Label 2");

const Id = document.getElementById("form");
function afficheForm(labea, labb) {
  let lab1 = document.createElement("label");
  lab1.textContent = labea;
  Id.appendChild(lab1);

  Id.appendChild(document.createElement("input"));
  Id.appendChild(document.createElement("br"));
  let lab2 = document.createElement("label");
  lab2.textContent = labb;
  Id.appendChild(lab2);
  Id.appendChild(document.createElement("input"));
  Id.appendChild(document.createElement("br"));
  let Sub = document.createElement("input");
  Sub.value = "Valider";

  Sub.type = "submit";
  Id.appendChild(Sub);

  let cancel = document.createElement("input");
  cancel.type = "reset";
  cancel.value = "Reinstaller";

  Id.appendChild(cancel);
}

afficheForm(labelA, labelB);
