const list = document.getElementById("list");

function addElement(val) {
  const item = document.createElement("li");

  item.textContent = val;

  list.appendChild(item);
}

let stop = true;
while (stop) {
  var listItem = prompt("Enter Item !");
  addElement(listItem);
  stop = window.confirm("Wanna add another one ? ");
}
