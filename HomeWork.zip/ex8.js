const a = Number(prompt("Enter Num A"));
const b = Number(prompt("Enter Num B"));
const c = Number(prompt("Enter Num C"));
let arr = [a, b, c];
let max = arr[0];
for (let i = 0; i < arr.length; i++) {
  if (arr[i] > max) max = arr[i];
}
alert("The max is " + max);
