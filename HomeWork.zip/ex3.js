const year = Number(prompt("Enter The Year"));

if (year % 4 == 0 && year % 100 == 0 && year % 400 == 0) {
  alert(year + " Is a leap Year");
} else {
  alert(year + " Is not a leap year ");
}
