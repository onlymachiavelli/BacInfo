const list = document.getElementById("list");

function addElement(val) {
  const item = document.createElement("li");

  item.textContent = val;

  list.appendChild(item);
}

const text = ["Un", "Deux", "Trois"];
for (let i = 0; i < text.length; i++) {
  addElement(text[i]);
}
